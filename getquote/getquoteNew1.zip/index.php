<?php
session_start();
ob_start();
	include ("connection.php");
	// include ("loginmodal.php");
	// include ("registrationmodal.php");
	//$sql="select * from category inner join subcategory on category.cat_id=subcategory.cat_id ";
	$sql="select * from category";
	$query=mysqli_query($con,$sql);
	$quer=mysqli_query($con,$sql);
	$head=mysqli_query($con,"select * from header");
	$header=mysqli_fetch_array($head);
	$logos=$header['logo'];
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Get & Compare Quotes</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="images/favicon.png">
  <link rel="stylesheet" href="css/bootstrap.min.css"> 
  <!-- <link rel="stylesheet" href="public/css/default.css" type="text/css"> -->

         	
 
  <style>
    
  .navbar, nav {
      margin-bottom: 4;
      border-radius: 4;
      align-items: center;
    }
    
 .dropdown:hover .dropdown-menu 
	{
    display: block;
    margin-top: 0; 
	}
.p
	{
		font-family:helvetica,verdana,arial,geneva,arial black;
	}

a {
		color: #800000;	
		font-size: 12px;
		padding-top: 10px;
	} 

  </style>

</head>

<body >
<nav class="navbar navbar-full navbar-light text-center" style="background-color: #800000;">
  <div class="container-fluid text-center center"><img src="images/Banner.png" align="center" alt="">
    <div class="navbar-header text-center">
      <a class="navbar-brand text-center" href="index.php"></a>
    </div>
    <ul class="nav navbar-nav text-center" style="background-color: white">
      <li class="active text-center"><a href="http://lasuri-insurance.com">Home</a></li>
     
	  <?php
		while($a=mysqli_fetch_array($query,MYSQLI_ASSOC))
		{	
			$cat_id=$a['cat_id'];
			$sql1="select * from subcategory where cat_id='".$cat_id."'";
			$query1=mysqli_query($con,$sql1);
			
			?>
			<li type="none" class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo $a['cat_name'] ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
			<?php
				while($b=mysqli_fetch_array($query1,MYSQLI_ASSOC))
				{
					
					echo '<li ><a href="index.php?page=plans&id='.$b["subcat_id"].'">'. $b['subcat_name'] .'</a></li>';
					
				}
			?>      
        </ul>
      </li>

			
			<?php
		}
		?>
	  
      <li class="active text-center"><a href="http://www.login.lasuri-insurance.com/loginmodal.php">Login</a></li>
      <li class="active text-center"><a href="http://www.login.lasuri-insurance.com/registrationmodal.php">Register</a></li>
    </ul>
	<ul class="nav navbar-nav navbar-right" style="background-color: white">
	<?php
		if(isset($_SESSION['insuranceuser']))
		{
			?>
			<li class="active"><a href="index.php?page=dashboard" ><span class="glyphicon glyphicon-user" ></span> Dashboard</a></li>
			<li class="active"><a href="logout.php" ><span class="glyphicon glyphicon-log-out" ></span> Logout</a></li>
			<?php
		}
		else {
	?>			
	 
      		<?php
		}
	?>
        </ul>
      </div>

</nav>


<?php
	@$opt=@$_GET['page'];
	if ($opt=='plans')
	{
		include('plans.php');
	}
	else if ($opt=='buy')
	{
		include('buy.php');
	}
	else if ($opt=='confirmbooking')
	{
		include('confirmbooking.php');
	}	
	else if ($opt=='pay')
	{
		include('pay.php');
	}
		else if ($opt=='dashboard')
	{
		include('dashboard.php');
	}
	else
	{		
	?>


  
<?php
}

?>
<footer class="text-center">
  <div class="">
            <img src="images/footer.jpg" alt="">
        </div>
</footer>
<script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
   <script src="js/jquery-1.11.1.min.js"></script>
  <script src="js/jquery-1.12.0.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/jquery.timer.js"></script>
  <link rel="stylesheet" href="js/jquery-ui.css">
  <script src="js/jquery-1.11.1.min.js"></script>
  <script src="js/jquery-ui-1.8.17.custom.min.js"></script>
  
		  <script type="text/javascript" src="js/jquery-1.12.0.js"></script>
        <script type="text/javascript" src="js/zebra_datepicker.js"></script>
        <script type="text/javascript" src="js/core.js"></script>
		
</body>
</html>

<?php
	ob_end_flush();
?>